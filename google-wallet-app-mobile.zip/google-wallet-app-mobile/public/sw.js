const CACHE_NAME = "wallet-app-v1"

self.addEventListener("install", (event) => {
  self.skipWaiting()
})

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
      )
    )
  )
  self.clients.claim()
})

// Network-first, falls back to cache when offline. Keeps dev/live-reload happy
// while still giving the "installed app" feel when the network drops.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return

  event.respondWith(
    fetch(event.request)
      .then((response) => {
        const copy = response.clone()
        caches.open(CACHE_NAME).then((cache) => {
          cache.put(event.request, copy).catch(() => {})
        })
        return response
      })
      .catch(() => caches.match(event.request))
  )
})
