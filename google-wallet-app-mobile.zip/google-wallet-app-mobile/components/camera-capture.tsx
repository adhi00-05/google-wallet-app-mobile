"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Camera, RotateCcw, X, Check, AlertCircle } from "lucide-react"

interface CameraCaptureProps {
  open: boolean
  onClose: () => void
  onCapture: (file: File) => void
}

export function CameraCapture({ open, onClose, onCapture }: CameraCaptureProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const streamRef = useRef<MediaStream | null>(null)

  const [error, setError] = useState<string | null>(null)
  const [photo, setPhoto] = useState<string | null>(null)
  const [facingMode, setFacingMode] = useState<"environment" | "user">("environment")

  useEffect(() => {
    if (!open) return

    let cancelled = false
    setError(null)
    setPhoto(null)

    async function startCamera() {
      try {
        stopCamera()
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode, width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false,
        })
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop())
          return
        }
        streamRef.current = stream
        if (videoRef.current) {
          videoRef.current.srcObject = stream
          await videoRef.current.play()
        }
      } catch (err) {
        console.error(err)
        setError(
          "Couldn't access the camera. Please allow camera permission for this site in your browser settings.",
        )
      }
    }

    startCamera()

    return () => {
      cancelled = true
      stopCamera()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, facingMode])

  function stopCamera() {
    streamRef.current?.getTracks().forEach((track) => track.stop())
    streamRef.current = null
  }

  function handleClose() {
    stopCamera()
    setPhoto(null)
    setError(null)
    onClose()
  }

  function takePhoto() {
    const video = videoRef.current
    const canvas = canvasRef.current
    if (!video || !canvas) return

    canvas.width = video.videoWidth
    canvas.height = video.videoHeight
    const ctx = canvas.getContext("2d")
    if (!ctx) return
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height)
    setPhoto(canvas.toDataURL("image/jpeg", 0.92))
  }

  function retake() {
    setPhoto(null)
  }

  function confirmPhoto() {
    const canvas = canvasRef.current
    if (!canvas) return
    canvas.toBlob(
      (blob) => {
        if (!blob) return
        const file = new File([blob], `receipt-${Date.now()}.jpg`, { type: "image/jpeg" })
        onCapture(file)
        handleClose()
      },
      "image/jpeg",
      0.92,
    )
  }

  if (!open) return null

  return (
    <div className="fixed inset-0 z-[100] bg-black flex flex-col">
      <div className="flex items-center justify-between px-4 py-3 text-white">
        <button onClick={handleClose} className="p-2 -ml-2" aria-label="Close camera">
          <X className="w-6 h-6" />
        </button>
        <span className="font-medium">Scan Receipt</span>
        <button
          onClick={() => setFacingMode((m) => (m === "environment" ? "user" : "environment"))}
          className="p-2 -mr-2"
          aria-label="Flip camera"
        >
          <RotateCcw className="w-6 h-6" />
        </button>
      </div>

      <div className="relative flex-1 bg-black flex items-center justify-center overflow-hidden">
        {error ? (
          <div className="text-center text-white px-8 space-y-3">
            <AlertCircle className="w-10 h-10 mx-auto text-red-400" />
            <p className="text-sm text-gray-200">{error}</p>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
          </div>
        ) : photo ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={photo || "/placeholder.svg"} alt="Captured receipt" className="max-h-full max-w-full object-contain" />
        ) : (
          <video ref={videoRef} playsInline muted className="max-h-full max-w-full object-contain" />
        )}
        <canvas ref={canvasRef} className="hidden" />
      </div>

      {!error && (
        <div className="p-6 flex items-center justify-center gap-6 bg-black">
          {photo ? (
            <>
              <Button
                variant="outline"
                className="bg-transparent text-white border-white/40 hover:bg-white/10"
                onClick={retake}
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Retake
              </Button>
              <Button onClick={confirmPhoto} className="bg-blue-600 hover:bg-blue-700">
                <Check className="w-4 h-4 mr-2" />
                Use Photo
              </Button>
            </>
          ) : (
            <button
              onClick={takePhoto}
              aria-label="Take photo"
              className="w-16 h-16 rounded-full border-4 border-white flex items-center justify-center active:scale-95 transition-transform"
            >
              <span className="w-12 h-12 rounded-full bg-white" />
            </button>
          )}
        </div>
      )}
    </div>
  )
}
