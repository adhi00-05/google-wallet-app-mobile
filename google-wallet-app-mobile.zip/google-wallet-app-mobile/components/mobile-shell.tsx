"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { Download, Wifi, Signal, BatteryFull } from "lucide-react"

/**
 * Wraps the entire app so it always *looks and behaves* like a phone app:
 *  - On a real phone / when installed as a PWA: fills the screen normally.
 *  - On a laptop / desktop browser: renders inside a phone-shaped frame
 *    with a fake status bar, notch and home-indicator, so the whole
 *    experience reads as "a mobile app running on your laptop".
 */
export function MobileShell({ children }: { children: React.ReactNode }) {
  const [isStandalone, setIsStandalone] = useState(false)
  const [time, setTime] = useState("")
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null)
  const [canInstall, setCanInstall] = useState(false)

  useEffect(() => {
    const standalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (window.navigator as any).standalone === true
    setIsStandalone(standalone)

    const updateTime = () =>
      setTime(new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }))
    updateTime()
    const interval = setInterval(updateTime, 1000 * 30)

    const onBeforeInstall = (e: Event) => {
      e.preventDefault()
      setDeferredPrompt(e)
      setCanInstall(true)
    }
    window.addEventListener("beforeinstallprompt", onBeforeInstall)

    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => {})
    }

    return () => {
      clearInterval(interval)
      window.removeEventListener("beforeinstallprompt", onBeforeInstall)
    }
  }, [])

  const handleInstall = async () => {
    if (!deferredPrompt) return
    deferredPrompt.prompt()
    await deferredPrompt.userChoice
    setDeferredPrompt(null)
    setCanInstall(false)
  }

  return (
    <div className="phone-stage">
      <div className="phone-frame">
        <div className="phone-notch" />
        <div className="phone-statusbar">
          <span className="phone-time">{time}</span>
          <div className="phone-status-icons">
            <Signal className="w-3.5 h-3.5" />
            <Wifi className="w-3.5 h-3.5" />
            <BatteryFull className="w-4 h-4" />
          </div>
        </div>

        <div className="phone-screen">{children}</div>

        <div className="phone-home-indicator" />
      </div>

      {!isStandalone && canInstall && (
        <button className="install-fab" onClick={handleInstall}>
          <Download className="w-4 h-4" />
          Install app
        </button>
      )}
    </div>
  )
}
