"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Upload, Camera, FileText, PenTool, ImageIcon, File, X, FileType } from "lucide-react"
import { CameraCapture } from "@/components/camera-capture"

interface StoredReceipt {
  id: string
  file: File
  previewUrl: string | null
  source: "upload" | "camera"
  addedAt: number
}

export function ReceiptUpload() {
  const [receipts, setReceipts] = useState<StoredReceipt[]>([])
  const [cameraOpen, setCameraOpen] = useState(false)
  const [manualReceipt, setManualReceipt] = useState({
    shopName: "",
    amount: "",
    date: "",
    items: "",
  })
  const [savedManualReceipts, setSavedManualReceipts] = useState<typeof manualReceipt[]>([])

  // Clean up object URLs when the component unmounts to avoid memory leaks
  useEffect(() => {
    return () => {
      receipts.forEach((r) => r.previewUrl && URL.revokeObjectURL(r.previewUrl))
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function addFiles(files: File[], source: "upload" | "camera") {
    const newReceipts: StoredReceipt[] = files.map((file) => ({
      id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
      file,
      previewUrl: file.type.startsWith("image/") ? URL.createObjectURL(file) : null,
      source,
      addedAt: Date.now(),
    }))
    setReceipts((prev) => [...newReceipts, ...prev])
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || [])
    if (files.length) addFiles(files, "upload")
    event.target.value = ""
  }

  const handleCameraCapture = (file: File) => {
    addFiles([file], "camera")
  }

  const removeReceipt = (id: string) => {
    setReceipts((prev) => {
      const target = prev.find((r) => r.id === id)
      if (target?.previewUrl) URL.revokeObjectURL(target.previewUrl)
      return prev.filter((r) => r.id !== id)
    })
  }

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!manualReceipt.shopName || !manualReceipt.amount) return
    setSavedManualReceipts((prev) => [manualReceipt, ...prev])
    setManualReceipt({ shopName: "", amount: "", date: "", items: "" })
  }

  const allReceiptsCount = receipts.length + savedManualReceipts.length

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Upload className="w-5 h-5" />
            <span>Upload Receipts</span>
          </CardTitle>
          <CardDescription>Add your receipts for better expense tracking</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="upload" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="upload">Upload File</TabsTrigger>
              <TabsTrigger value="camera">Camera</TabsTrigger>
              <TabsTrigger value="manual">Manual Entry</TabsTrigger>
              <TabsTrigger value="history">
                History{allReceiptsCount > 0 ? ` (${allReceiptsCount})` : ""}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="upload" className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Upload Receipt</h3>
                <p className="text-gray-500 mb-4">Choose photos or PDFs from your device</p>
                <Input
                  type="file"
                  multiple
                  accept="image/*,.pdf"
                  onChange={handleFileUpload}
                  className="hidden"
                  id="file-upload"
                />
                <Label htmlFor="file-upload">
                  <Button variant="outline" className="cursor-pointer bg-transparent" asChild>
                    <span>
                      <File className="w-4 h-4 mr-2" />
                      Choose Files
                    </span>
                  </Button>
                </Label>
              </div>

              {receipts.filter((r) => r.source === "upload").length > 0 && (
                <ReceiptGrid
                  receipts={receipts.filter((r) => r.source === "upload")}
                  onRemove={removeReceipt}
                />
              )}
            </TabsContent>

            <TabsContent value="camera" className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <Camera className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Capture Receipt</h3>
                <p className="text-gray-500 mb-4">Use your camera to scan receipts</p>
                <Button onClick={() => setCameraOpen(true)}>
                  <Camera className="w-4 h-4 mr-2" />
                  Open Camera
                </Button>
              </div>

              {receipts.filter((r) => r.source === "camera").length > 0 && (
                <ReceiptGrid
                  receipts={receipts.filter((r) => r.source === "camera")}
                  onRemove={removeReceipt}
                />
              )}
            </TabsContent>

            <TabsContent value="manual" className="space-y-4">
              <form onSubmit={handleManualSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="shopName">Shop Name</Label>
                    <Input
                      id="shopName"
                      value={manualReceipt.shopName}
                      onChange={(e) => setManualReceipt((prev) => ({ ...prev, shopName: e.target.value }))}
                      placeholder="Enter shop name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="amount">Amount</Label>
                    <Input
                      id="amount"
                      type="number"
                      value={manualReceipt.amount}
                      onChange={(e) => setManualReceipt((prev) => ({ ...prev, amount: e.target.value }))}
                      placeholder="Enter amount"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="date">Date</Label>
                  <Input
                    id="date"
                    type="date"
                    value={manualReceipt.date}
                    onChange={(e) => setManualReceipt((prev) => ({ ...prev, date: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="items">Items</Label>
                  <Textarea
                    id="items"
                    value={manualReceipt.items}
                    onChange={(e) => setManualReceipt((prev) => ({ ...prev, items: e.target.value }))}
                    placeholder="List items purchased (one per line)"
                    rows={4}
                  />
                </div>
                <Button type="submit" className="w-full">
                  <PenTool className="w-4 h-4 mr-2" />
                  Save Receipt
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="history" className="space-y-4">
              {allReceiptsCount === 0 ? (
                <div className="text-center py-8">
                  <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No receipts uploaded yet</h3>
                  <p className="text-gray-500">Start uploading receipts to see them here</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {receipts.length > 0 && <ReceiptGrid receipts={receipts} onRemove={removeReceipt} />}
                  {savedManualReceipts.map((r, i) => (
                    <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border">
                      <div className="flex items-center space-x-3">
                        <PenTool className="w-4 h-4 text-gray-500" />
                        <div>
                          <p className="text-sm font-medium">{r.shopName}</p>
                          <p className="text-xs text-gray-500">
                            {r.date || "No date"} · ₹{r.amount}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <CameraCapture open={cameraOpen} onClose={() => setCameraOpen(false)} onCapture={handleCameraCapture} />
    </div>
  )
}

function ReceiptGrid({
  receipts,
  onRemove,
}: {
  receipts: StoredReceipt[]
  onRemove: (id: string) => void
}) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
      {receipts.map((r) => (
        <div key={r.id} className="relative group border rounded-lg overflow-hidden bg-gray-50">
          <button
            onClick={() => onRemove(r.id)}
            className="absolute top-1 right-1 z-10 bg-black/60 text-white rounded-full p-1 hover:bg-black/80"
            aria-label="Remove receipt"
          >
            <X className="w-3 h-3" />
          </button>
          <div className="aspect-square flex items-center justify-center bg-white">
            {r.previewUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={r.previewUrl || "/placeholder.svg"} alt={r.file.name} className="w-full h-full object-cover" />
            ) : (
              <FileType className="w-10 h-10 text-gray-400" />
            )}
          </div>
          <div className="p-2 flex items-center gap-1">
            <ImageIcon className="w-3 h-3 text-gray-400 shrink-0" />
            <span className="text-[11px] truncate">{r.file.name}</span>
          </div>
          <div className="px-2 pb-2 text-[10px] text-gray-500">{(r.file.size / 1024).toFixed(1)} KB</div>
        </div>
      ))}
    </div>
  )
}
